
package com.fenix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FenixApplication {
    public static void main(String[] args) {
        SpringApplication.run(FenixApplication.class, args);
    }
}
